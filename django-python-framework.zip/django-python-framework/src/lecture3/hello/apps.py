from django.apps import AppConfig


class HelloConfig(AppConfig):
    name = 'hello'
